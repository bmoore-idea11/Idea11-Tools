import logging

from mypy_boto3_logs.type_defs import LogStreamTypeDef

from i11tools.aws.session import BoundSession
from i11tools.aws.type_defs import LambdaFunctionName

log = logging.getLogger(__name__)

def get_last_log_stream(
    session: BoundSession,
    name: LambdaFunctionName,
) -> LogStreamTypeDef | None:
    cloudwatch_client = session.client("logs")
    log_group_name = f"/aws/lambda/{name}"
    log.info(f"Querying log group named {log_group_name!r}")
    try:
        log_streams_resp = cloudwatch_client.describe_log_streams(
            logGroupName=log_group_name,
            orderBy="LastEventTime",
            descending=True,
            limit=1,
        )
        log_streams = log_streams_resp["logStreams"]
    except cloudwatch_client.exceptions.ResourceNotFoundException:
        log_streams = None
    if not log_streams:
        log.debug(f"No log streams found in {session.region_name} for Lambda function {name}")
        return None
    return log_streams[0]