import csv
import enum
import json
import logging
import sys
from pathlib import Path
from pprint import pprint

import click

from i11tools.aws.lambda_.function_details import LambdaFunctionsByAwsProfile
from i11tools.aws.lambda_.querying import lambda_functions_in_profile
from i11tools.aws.lambda_.runtimes import uses_nodejs_lte, uses_python_lte

class OutputTypes(enum.Enum):
    print = enum.auto()
    csv = enum.auto()

LOG_LEVEL = logging.INFO
PRINT_WIDTH = 120
OUTPUT_CSV_FILENAME = Path("lambda_functions.csv")

log = logging.getLogger(__name__)

@click.group("lambda")
def lambda_subcommand():
    pass


@lambda_subcommand.command("list-deprecated")
@click.option(
    "-o",
    "--output",
    type=click.Choice(OutputTypes, case_sensitive=False),
    multiple=True,
    default=(OutputTypes.print,)
)
@click.pass_context
def list_deprecated(
    ctx: click.Context,
    output: tuple[OutputTypes] = (OutputTypes.print,),
) -> None:
    logging.basicConfig(stream=sys.stdout, level=LOG_LEVEL)

    results = lambda_functions_in_profile(
        ctx.obj.sessions,
        filter=(
            lambda func: (
                uses_python_lte(func, (3, 10))
                or uses_nodejs_lte(func, 18)
            )
        )
    )
    if OutputTypes.print in output:
        print_output(results)
        
    if OutputTypes.csv in output:
        csv_output(results)


def print_output(results: LambdaFunctionsByAwsProfile) -> None:
    summarised_for_print = {
        profile_name: {
            region_name: [
                {
                    "name": function.name,
                    "runtime": function.runtime,
                    "last_log_event_timestamp": function.last_log_event_timestamp_str,
                }
                for function in functions
            ] for region_name, functions in per_profile.items()
        } for profile_name, per_profile in results.items()
    }
    pprint(summarised_for_print, sort_dicts=False, width=PRINT_WIDTH)


def csv_output(results: LambdaFunctionsByAwsProfile) -> None:
    with OUTPUT_CSV_FILENAME.open("w", newline="") as csv_file:
        fields = [
            "AWS Profile",
            "AWS Region",
            "Runtime",
            "Function Name",
            "Last Log Event Time",
            "CloudFormation Stack Name",
            "CloudFormation Logical ID",
            "All Tags",
        ]
        writer = csv.DictWriter(csv_file, fieldnames=fields)
        writer.writeheader()
        for profile_name, per_profile in results.items():
                for region_name, per_region in per_profile.items():
                    for function in per_region:
                        writer.writerow({
                            "AWS Profile": profile_name,
                            "AWS Region": region_name,
                            "Runtime": function.runtime,
                            "Function Name": function.name,
                            "Last Log Event Time": function.last_log_event_timestamp_str,
                            "CloudFormation Stack Name": function.cloudformation_stack_name or "",
                            "CloudFormation Logical ID": function.cloudformation_logical_id or "",
                            "All Tags": json.dumps(function.tags) if function.tags else "",
                        })
        log.info(f"CSV output to {OUTPUT_CSV_FILENAME}")