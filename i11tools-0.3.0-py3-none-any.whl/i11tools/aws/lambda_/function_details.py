import dataclasses
import logging
from collections.abc import MutableMapping, Sequence
from datetime import datetime, timezone
from dateutil.tz import tzlocal

from mypy_boto3_lambda.literals import RuntimeType
from mypy_boto3_lambda.type_defs import FunctionConfigurationTypeDef
from mypy_boto3_logs.type_defs import LogStreamTypeDef

from i11tools.aws.type_defs import (
    AwsProfileName,
    AwsRegionName,
    LambdaFunctionName,
)

log = logging.getLogger(__name__)

@dataclasses.dataclass
class LambdaFunctionDetails:
    name: LambdaFunctionName
    configuration: FunctionConfigurationTypeDef
    tags: dict[str, str]
    last_log_stream: LogStreamTypeDef | None
   
    @property
    def runtime(self) -> RuntimeType | None:
        return self.configuration.get("Runtime")
    
    @property
    def last_log_event_timestamp(self) -> datetime | None:
        if self.last_log_stream is None:
            return None
        last_event_timestamp_as_ms = self.last_log_stream.get("lastEventTimestamp")
        if last_event_timestamp_as_ms is None:
            return None
        # Convert milliseconds-since-epoch UTC to datetime in local timezone
        return (
            datetime
                .fromtimestamp(last_event_timestamp_as_ms / 1000.0, tz=timezone.utc)
                .astimezone(tz=tzlocal())
        )
    
    @property
    def last_log_event_timestamp_str(self) -> str:
        timestamp = self.last_log_event_timestamp
        return (
            "" if timestamp is None
            else timestamp.isoformat(timespec="minutes"))

    @property
    def cloudformation_stack_name(self) -> str | None:
        return self.tags.get("aws:cloudformation:stack-name")

    @property
    def cloudformation_stack_id(self) -> str | None:
        return self.tags.get("aws:cloudformation:stack-id")

    @property
    def cloudformation_logical_id(self) -> str | None:
        return self.tags.get("aws:cloudformation:logical-id")


    def sort_key(self) -> tuple[RuntimeType | None, LambdaFunctionName]:
        return (self.runtime, self.name)


LambdaFunctionsByAwsRegion = MutableMapping[AwsRegionName, Sequence[LambdaFunctionDetails]]
LambdaFunctionsByAwsProfile = MutableMapping[AwsProfileName, LambdaFunctionsByAwsRegion]