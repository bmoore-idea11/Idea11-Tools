import logging
from collections.abc import Iterator

from mypy_boto3_lambda import LambdaClient
from mypy_boto3_lambda.type_defs import FunctionConfigurationTypeDef

from i11tools.aws.session import AwsSessions, BoundSession
from i11tools.aws.lambda_.function_details import (
    LambdaFunctionsByAwsProfile,
    LambdaFunctionDetails,
)
from i11tools.aws.lambda_.logs import get_last_log_stream
from i11tools.aws.type_defs import LambdaFunctionName, LambdaFunctionFilter

log = logging.getLogger(__name__)


def lambda_functions_in_profile(
    aws_sessions: AwsSessions,
    filter: LambdaFunctionFilter | None = None,
    sort: bool = True,
    include_last_log_stream: bool = True,
) -> LambdaFunctionsByAwsProfile:
    results: LambdaFunctionsByAwsProfile = {}

    for session in aws_sessions.for_each_profile_and_region():
        log.info(f"Checking account {session.profile_name}, region {session.region_name}...")

        if session.profile_name not in results:
            results[session.profile_name] = {}
        results_by_region = results[session.profile_name]

        results_in_region = list(
            function_details(
                session,
                filter,
                include_last_log_stream=include_last_log_stream
            ))
        if results_in_region:
            if sort:
                results_in_region.sort(key=lambda i: i.sort_key())
            results_by_region[session.region_name] = results_in_region

    return results


def function_details(
    session: BoundSession,
    filter: LambdaFunctionFilter | None = None,
    include_last_log_stream: bool = True,
) -> Iterator[LambdaFunctionDetails]:
    lambda_client = session.client("lambda")
    for function_configuration in iter_functions(lambda_client, filter):
        function_name = function_configuration.get("FunctionName")
        if function_name is None:
            log.error("Somehow found a Lambda function with no name")
            continue

        function_name = LambdaFunctionName(function_name)
        full_info = lambda_client.get_function(FunctionName=function_name)

        yield LambdaFunctionDetails(
            name=function_name,
            configuration=function_configuration,
            tags=full_info.get("Tags", {}),
            last_log_stream=(
                get_last_log_stream(session, function_name)
                if include_last_log_stream else None
            ),
        )


def iter_functions(
    lambda_client: LambdaClient,
    filter: LambdaFunctionFilter | None = None,
) -> Iterator[FunctionConfigurationTypeDef]:
    for page in lambda_client.get_paginator("list_functions").paginate():
        for func in page["Functions"]:
            if filter is None or filter(func):
                yield func
