from dataclasses import dataclass

import click

from i11tools.aws.session import AwsSessions
from i11tools.aws.profile import parse_profile_selection
from i11tools.aws.region import parse_region_selection
from i11tools.aws_cli.lambda_ import lambda_subcommand


@dataclass
class AwsToolsContextObject:
    sessions: AwsSessions


@click.group("aws")
@click.option("--profiles")
@click.option("--regions")
@click.pass_context
def aws_subcommand(
    ctx: click.Context,
    profiles: str | None = None,
    regions: str | None = None,
):
    # TODO: support single default profile or AWS_PROFILE env var
    if not profiles:
        raise click.UsageError("Please specify some profiles with --profiles")

    try:
        profile_selection = parse_profile_selection(profiles)
    except ValueError as e:
        raise click.BadParameter(e.args[0])
    click.echo(f"Running for profiles: {profile_selection.all()}")

    region_selection = parse_region_selection(regions)
    if region_selection.allowed_regions:
        click.echo(f"Limiting to regions: {region_selection.allowed_regions}")

    ctx.obj = AwsToolsContextObject(
        sessions = AwsSessions(
            profile_selection=profile_selection,
            region_selection=region_selection,
        )
    )

aws_subcommand.add_command(lambda_subcommand)