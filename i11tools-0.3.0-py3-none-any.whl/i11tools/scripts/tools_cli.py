import click
from i11tools.aws_cli.main import aws_subcommand

@click.group("i11tools")
@click.option('--debug/--no-debug')
def tools(debug: bool):
    pass


tools.add_command(aws_subcommand)