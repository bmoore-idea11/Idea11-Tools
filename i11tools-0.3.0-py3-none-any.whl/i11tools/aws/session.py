from collections.abc import Iterator
from dataclasses import dataclass, field
from typing import Literal, overload

from boto3.session import Session
from mypy_boto3_ec2 import EC2Client
from mypy_boto3_lambda import LambdaClient

from i11tools.aws.profile import AwsProfileSelection
from i11tools.aws.region import AwsRegionSelection
from i11tools.aws.type_defs import AwsProfileName, AwsRegionName

# TODO: there must be a way to simplify the caching here

class BoundSession:
    def __init__(
        self,
        session: Session,
        profile_name: AwsProfileName,
        region_name: AwsRegionName,
    ):
        self._session = session
        self._profile_name = profile_name
        self._region_name = region_name

    @property
    def profile_name(self) -> AwsProfileName:
        return self._profile_name
    
    @property
    def region_name(self) -> AwsRegionName:
        return self._region_name

    @overload
    def client(self, service_name: Literal["ec2"]) -> EC2Client:
        ...
    @overload
    def client(self, service_name: Literal["lambda"]) -> LambdaClient:
        ...
    def client(self, service_name):
        return self._session.client(service_name, region_name=self._region_name)

SessionCache = dict[AwsProfileName, Session]
BoundSessionCache = dict[tuple[AwsProfileName, AwsRegionName], BoundSession]
RegionsCache = dict[AwsProfileName, list[AwsRegionName]]

@dataclass
class AwsSessions:
    profile_selection: AwsProfileSelection
    region_selection: AwsRegionSelection
    _sessions: SessionCache = field(default_factory=dict)
    _bound_sessions: BoundSessionCache = field(default_factory=dict)
    _regions_for_profile: RegionsCache = field(default_factory=dict)

    def _session(self, profile_name: AwsProfileName) -> Session:
        if profile_name not in self._sessions:
            self._sessions[profile_name] = Session(profile_name=profile_name)
        return self._sessions[profile_name]
    
    def _bound_session(
        self,
        profile_name: AwsProfileName,
        region_name: AwsRegionName,
    ) -> BoundSession:
        cache_key = (profile_name, region_name)
        if cache_key not in self._bound_sessions:
            self._bound_sessions[cache_key] = BoundSession(
                session=self._session(profile_name),
                profile_name=profile_name,
                region_name=region_name,
            )
        return self._bound_sessions[cache_key]

    def _available_regions_for_profile(
        self,
        profile_name: AwsProfileName,
    ) -> list[AwsRegionName]:
        if profile_name not in self._regions_for_profile:
            session = self._session(profile_name)
            ec2_client = session.client("ec2")
            self._regions_for_profile[profile_name] = sorted(
                AwsRegionName(region["RegionName"])
                for region in ec2_client.describe_regions()["Regions"]
                if "RegionName" in region
            )
        return self._regions_for_profile[profile_name]

    def for_each_profile_and_region(self) -> Iterator[BoundSession]:
        for profile_name in self.profile_selection.all():
            available_regions = self._available_regions_for_profile(profile_name)
            for region_name in self.region_selection.select_from(available_regions):
                yield self._bound_session(profile_name, region_name)