from mypy_boto3_lambda.type_defs import FunctionConfigurationTypeDef


def uses_python_lte(func: FunctionConfigurationTypeDef, version: tuple[int, int]) -> bool:
    runtime = func.get("Runtime")
    if runtime is None:
        return False
    if not runtime.startswith("python"):
        return False
    major, minor = runtime.removeprefix("python").split(".")
    return (int(major), int(minor)) <= version

def uses_nodejs_lte(func: FunctionConfigurationTypeDef, version: int) -> bool:
    runtime = func.get("Runtime")
    if runtime is None:
        return False
    if not runtime.startswith("nodejs"):
        return False
    major, _not_used = runtime.removeprefix("nodejs").split(".")
    return int(major) <= version