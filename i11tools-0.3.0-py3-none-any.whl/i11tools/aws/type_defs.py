from collections.abc import Callable
from typing import NewType

from mypy_boto3_lambda.type_defs import FunctionConfigurationTypeDef

AwsProfileName = NewType("AwsProfileName", str)
AwsRegionName = NewType("AwsRegionName", str)
LambdaFunctionName = NewType("LambdaFunctionName", str)

LambdaFunctionFilter = Callable[[FunctionConfigurationTypeDef], bool]