from dataclasses import dataclass

from i11tools.aws.type_defs import AwsRegionName

# TODO: allow patterns like "ap-southeast-*" or "eu-*"
# TODO: validate region names at this point

@dataclass
class AwsRegionSelection:
    allowed_regions: list[AwsRegionName]

    def is_allowed_region(self, region_name: AwsRegionName) -> bool:
        if not self.allowed_regions:
            # Special case: no regions selected, allow all regions
            return True
        return region_name in self.allowed_regions

    def select_from(self, available_regions: list[AwsRegionName]) -> list[AwsRegionName]:
        return [
            region_name for region_name in available_regions
            if self.is_allowed_region(region_name)
        ]


def parse_region_selection(expression: str | None) -> AwsRegionSelection:
    if not expression:
        return AwsRegionSelection(allowed_regions=[])
    # TODO: for now we just support exact region names comma-separated
    # TODO: validate region names
    region_names = [
        AwsRegionName(region_name.strip()) for region_name in expression.split(",")]
    return AwsRegionSelection(allowed_regions=region_names)
