import glob
import re
from dataclasses import dataclass

from boto3.session import Session

from i11tools.aws.type_defs import AwsProfileName


@dataclass
class AwsProfileSelection:
    profile_names: list[AwsProfileName]

    def all(self):
        return self.profile_names


def parse_profile_selection(expression: str) -> AwsProfileSelection:
    default_session = Session()
    profile_names = sum(
        (
            _parse_profile_selection_subexpr(default_session, subexpr.strip())
            for subexpr in expression.split(",")
        ),
        []
    )
    return AwsProfileSelection(profile_names=profile_names)


def _parse_profile_selection_subexpr(session: Session, subexpr: str) -> list[AwsProfileName]:
    if "*" in subexpr or "?" in subexpr:
        pattern = re.compile(glob.translate(subexpr))
        matched_names = [
            AwsProfileName(profile_name) for profile_name
            in session.available_profiles
            if pattern.match(profile_name)
        ]
        if not matched_names:
            raise ValueError(f"Could not match any AWS profiles with pattern {subexpr!r}")
        return matched_names
    else:
        if subexpr not in session.available_profiles:
            raise ValueError(f"Could not find AWS profile named {subexpr!r}")
        return [AwsProfileName(subexpr)]